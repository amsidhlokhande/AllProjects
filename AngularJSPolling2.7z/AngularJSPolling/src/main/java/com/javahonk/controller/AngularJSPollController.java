package com.javahonk.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AngularJSPollController {
	
	@RequestMapping(value = "/pollDataFromServer")
	public @ResponseBody List<Integer> populateActivePSwapBasket() {		
		
		Random rand = new Random();
	    Integer randomNum = rand.nextInt();		
		List<Integer> list = new ArrayList<Integer>();
		list.add(randomNum);		
		return list;
	}

}
